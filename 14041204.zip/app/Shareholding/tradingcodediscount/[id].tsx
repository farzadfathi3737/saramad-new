import FDateField from '@/app/components/inputs/dateField';
import FSelectModelField from '@/app/components/inputs/selectModelField';
import FTextField from '@/app/components/inputs/textField';
import { ColoredToast } from '@/app/components/Notifications/colorNotification';
import { useSubPage } from '@/app/components/Notifications/useSubPage';
import { useLanguage } from '@/contexts/LanguageContext';
import { IDataModel } from '@/interface/dataModel';
import { apiFetch } from '@/lib/apiFetch';
import { getEntityModel } from '@/models/entity';
import { IRootState } from '@/store';
import { ActionIcon, Tooltip } from '@mantine/core';
import { Field, Form, Formik } from 'formik';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import * as Yup from 'yup';

const Edit = ({ id, tradingCodeId, tradingCode }: { id: string, tradingCodeId: string, tradingCode: string }) => {
    const { t } = useLanguage();
    const subPage = useSubPage();
    const [model, setModel] = useState<IDataModel>();
    const [data, setData] = useState<any>();
    const appConfig = useSelector((state: IRootState) => state.appConfig);
    const [isLoading, setIsLoading] = useState<boolean>(false);

    // console.log("id------------------>>>>", id);
    useEffect(() => {
        const setdata = async () => {
            const _model = await getEntityModel('tradingcodediscount');
            setModel(_model);
        };

        setdata();
    }, []);

    useEffect(() => {
        if (id && model) {
            fetchData(id);
        }
    }, [id, model]);

    const fetchData = async (id: string) => {
        setIsLoading(true);

        const res = await apiFetch(`${model?.read?.url.replace('{id}', id)}`);

        if (res.ok) {
            const result = await res?.json();
            setData(result);
            console.log(result);
            setIsLoading(false);
        } else {
            setData(undefined);
            setIsLoading(false);
        }
    };

    const SignupSchema = Yup.object().shape({
        tradingCode: Yup.string().required(t('required').toString()),
        type: Yup.string().required(t('required').toString()),
    });

    const handleAddClick = async (data: any) => {
        setIsLoading(true);
        console.log(data);

        data.tradingCodeId = tradingCodeId;

        //const res = await fetch(`${model?.update?.url}`, {
        const res = await fetch(`${model?.update?.url.replace('{id}', id)}`, {
            method: 'put',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (res.ok) {
            const result = res && (await res?.json());
            //setInitialRecords(result);
            //setAddModal(false);
            //fetchData();
            setIsLoading(false);
            subPage('companytradingcode', 'tradingcodediscount', [{ key: 'tradingCodeId', value: tradingCodeId }, { key: 'tradingCode', value: tradingCode }], undefined)
        } else {
            const result = res && (await res?.json());
            ColoredToast('danger', result);
        }
        setIsLoading(false);
    };

    return (
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-1">
            <div className="panel h-full w-full px-0">
                {/* <div className="mb-5 flex h-[3rem] items-start justify-start border-b-2 px-5 pb-3">
                    <div>
                        <Tooltip label={t('back')}>
                            <ActionIcon color="inheritans" className="flex items-center justify-center rounded-[50%] p-5 hover:bg-inherit hover:text-blue-900" onClick={() => router.back()}>
                                <FontAwesomeIcon icon={faArrowRight} size="lg" className="ml-2" />
                            </ActionIcon>
                        </Tooltip>
                    </div>
                    <div className="p-2">تعریف تخفیف کارگزاری - {tradingCode}</div>
                </div> */}

                <div className="flex h-[3rem] items-start justify-start border-b border-gray-300 pl-3">
                    <div className='flex border-l h-full border-inherit justify-center items-center'>
                        <Tooltip label={t('back')}>
                            <div
                                className="pr-3 flex items-center w-full h-full bg-none hover:bg-gray-500 text-secondary text-gray-900 hover:text-gray-50"
                                onClick={() => subPage('companytradingcode', 'tradingcodediscount', [{ key: 'tradingCodeId', value: tradingCodeId }, { key: 'tradingCode', value: tradingCode }], undefined)}>
                                <i className={`fa-duotone fa-solid fa-chevron-right text-xl ml-2`} />
                            </div>
                        </Tooltip>
                    </div>
                    <div className='px-2 h-full flex flex-col justify-center align-middle'>
                        <div className="p-2">ویرایش تخفیف کارگزاری - {tradingCode}</div>
                    </div>
                </div>
                {data &&
                    <div className="table-responsive px-5">
                        <div className="p-5">
                            <Formik
                                initialValues={data}
                                //validationSchema={SignupSchema}
                                onSubmit={(values) => {
                                    handleAddClick(values);
                                }}
                            >
                                <Form>
                                    <div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-2">
                                        <div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-2">
                                            <div className="w-full">
                                                <Field
                                                    id="brokerId"
                                                    name="brokerId"
                                                    label={'نام کارگزار'}
                                                    listRefName="stockbroker"
                                                    staticParams={[{ name: 'CompanyId', value: appConfig.company.id }]}
                                                    component={FSelectModelField}
                                                />
                                            </div>
                                            <div className="w-full">
                                                <Field id="percentage" name="percentage" label={t('percentage')} component={FTextField} />
                                            </div>
                                        </div>
                                        <div className="w-full"></div>
                                        <div className="grid w-full grid-cols-1 gap-2 sm:grid-cols-2">
                                            <div className="w-full">
                                                <Field id="validFrom" name="validFrom" label={t('validFrom')} component={FDateField} />
                                            </div>
                                            <div className="w-full">
                                                <Field id="validTo" name="validTo" label={t('validTo')} component={FDateField} />
                                            </div>
                                        </div>
                                        <div className="w-full"></div>
                                    </div>

                                    <div className="mt-8 flex items-center justify-end">
                                        <button type="button"
                                            onClick={() => subPage('companytradingcode', 'tradingcodediscount', [{ key: 'tradingCodeId', value: tradingCodeId }, { key: 'tradingCode', value: tradingCode }], undefined)}
                                            className="btn btn-outline-[#2D9AA0] font-iranyekan">
                                            {t('cancel')}
                                        </button>

                                        <button type="submit" className="btn btn-outline mr-3 flex items-center bg-[#2D9AA0] font-iranyekan text-[#fff]">
                                            {/* <IconPencil className="ltr:mr-1 rtl:ml-1 rtl:rotate-180" /> */}
                                            {t('save')}
                                        </button>
                                    </div>
                                </Form>
                            </Formik>
                        </div>
                    </div>
                }
            </div>
        </div>
    );
};

export default Edit;
