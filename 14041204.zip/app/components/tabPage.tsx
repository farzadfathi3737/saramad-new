"use client";

import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";

import { ActionIcon, Tooltip } from "@mantine/core";
import { setTabs, setActiveTab } from '@/store/appConfigSlice';
import { IRootState } from "@/store";
import { useLanguage } from '@/contexts/LanguageContext';

import Dashboard from "../dashboard/page";

import Company from "../Shareholding/company";
import CompanyAdd from "../Shareholding/company/add";
import CompanyEdit from "../Shareholding/company/[id]";

import FiscalYear from "../Shareholding/fiscalyear";
import FiscalYearAdd from "../Shareholding/fiscalyear/add";
import FiscalYearEdit from "../Shareholding/fiscalyear/[id]";

import CompanyTradingCode from "../Shareholding/companytradingcode";
import CompanyTradingCodeAdd from "../Shareholding/companytradingcode/add";
import CompanyTradingCodeEdit from "../Shareholding/companytradingcode/[id]";
import TradingCodeDiscount from "../Shareholding/tradingcodediscount";
import TradingCodeDiscountAdd from "../Shareholding/tradingcodediscount/add";
import TradingCodeDiscountEdit from "../Shareholding/tradingcodediscount/[id]";

import Stock from "../Shareholding/stock";
import StockView from "../Shareholding/stock/[id]";

import Share from "../Shareholding/share";
import ShareAdd from "../Shareholding/share/add";
import ShareAddT from "../Shareholding/share/addt";
import ShareEdit from "../Shareholding/share/[id]";


import ShareRelationType from "../Shareholding/sharerelationtype";
import ShareRelationTypeAdd from "../Shareholding/sharerelationtype/add";
import ShareRelationTypeEdit from "../Shareholding/sharerelationtype/[id]";

import CompanyBroker from "../Shareholding/companybroker";
import CompanyBrokerAdd from "../Shareholding/companybroker/add";
import CompanyBrokerAll from "../Shareholding/companybroker/all";
import CompanyBrokerEdit from "../Shareholding/companybroker/[id]";
import CompanyBrokerCode from "../Shareholding/companybroker/code/[id]";

import Companybrokerdiscount from "../Shareholding/companybrokerdiscount";
import CompanybrokerdiscountAdd from "../Shareholding/companybrokerdiscount/add";
import CompanybrokerdiscountEdit from "../Shareholding/companybrokerdiscount/[id]";

import BuySell from "../reports/buysell";
import StackedBuySell from "../reports/stackedbuysell";
import ShareTurnover from "../reports/shareturnover";
import Cardex from "../reports/cardex";
import StackedCardex from "../reports/stackedcardex";
import ShareBalance from "../reports/sharebalance";
import RealizedProfit from "../reports/realizedprofit";
import InvestmentDepreciationReserve from "../reports/investmentdepreciationreserve";
import CapitalRaise from "../reports/capitalraise";
import CashDividend from "../reports/cashdividend";
import CashDividendDeposit from "../reports/cashdividenddeposit";
import MarketNotice from "../reports/marketnotice";
import Comprehensive from "../reports/comprehensive";
import Consolidation from "../reports/consolidation";

import Shareinitialbalance from "../Shareholding/shareinitialbalance";
import ShareinitialbalanceAdd from "../Shareholding/shareinitialbalance/add";
import ShareinitialbalanceEdit from "../Shareholding/shareinitialbalance/[id]";

import TransactionImportSession from "../Shareholding/transactionImportsession";
import TransactionImportSessionDetail from "../Shareholding/transactionImportsession/[id]";
import TransactionImportSessionTransaction from "../Shareholding/transactionImportsession/[id]/transaction";

import ShareTransactionBatch from "../Shareholding/sharetransactionbatch";

import ShareTransactionBatchNoBurs from "../Shareholding/sharetransactionbatchnoburs";
import ShareTransactionBatchNoBursAdd from "../Shareholding/sharetransactionbatchnoburs/add";
import ShareTransactionBatchNoBursEdit from "../Shareholding/sharetransactionbatchnoburs/[id]";

import ShareTransactionBatchTadilat from "../Shareholding/sharetransactionbatchtadilat";

import TransferCodeToCode from "../Shareholding/transfercodetocode";
import TransferCodeToCodeAdd from "../Shareholding/transfercodetocode/add";

import ShareMeeting from "../Shareholding/shareMeeting";

import BrokerContradictions from "../Shareholding/brokercontradictions";

import OptionContract from "../Shareholding/optioncontract";

import TransactionCommission from "../Shareholding/transactioncommission";

import TransactionCommissionDiscount from "../Shareholding/transactioncommissiondiscount";
import TransactionCommissionDiscountapply from "../Shareholding/transactioncommissiondiscount/apply";
import TransactionCommissionDiscountremove from "../Shareholding/transactioncommissiondiscount/remove";

import ArticleElements from "../Shareholding/accountings/articleelements";
import ArticleElementsAdd from "../Shareholding/accountings/articleelements/add";
import ArticleElementsEdit from "../Shareholding/accountings/articleelements/[id]";

import JournalArticle from "../Shareholding/accountings/journalarticle";

import VoucherTemplates from "../Shareholding/accountings/vouchertemplates";
import VoucherTemplatesAdd from "../Shareholding/accountings/vouchertemplates/add";


import { IKeyValue, ITabData } from "@/interface/dataModel";
import { title } from "process";
import Jobs from "../Shareholding/jobs";
import Running from "../Shareholding/running";
import Finished from "../Shareholding/finished";

export default function TabsWithRouting() {
    const { t } = useLanguage();
    const router = useRouter();
    const searchParams = useSearchParams();
    const dispatch = useDispatch();
    const appConf = useSelector((state: IRootState) => state.appConfig);

    useEffect(() => {
        // const savedTabs: ITabData[] =
        //     JSON.parse(localStorage.getItem("tabsData") || "[]");
        // const _activeTab: number | null = Number(localStorage.getItem("activeTab")) || null;

        // setTabs(savedTabs);
        // setActiveTab(_activeTab);

        dispatch(setTabs(JSON.parse(localStorage.getItem("tabsData") || JSON.stringify([{
            id: "dashboard",
            key: "dashboard",
            name: "dashboard",
            title: "داشبورد",
            orter: 0,
            filters: [],
            params: []
        }])
        ))!);
        dispatch(setActiveTab(localStorage.getItem('activeTab'!) || 'dashboard')!);

        const tabFromQuery = searchParams.get("tab");

        if (tabFromQuery && appConf.tabs.some((t) => t.id === tabFromQuery)) {
            setActiveTab(tabFromQuery);
        } else if (appConf.tabs.length > 0) {
            setActiveTab(appConf.tabs[0].id);
        }
    }, [searchParams]);

    const removeTab = (id: string) => {
        const deletedIndex = appConf.tabs.findIndex(t => t.id === id);
        const updatedTabs = appConf.tabs.filter((tab) => tab.id !== id);

        // ابتدا تب‌ها را update کن
        dispatch(setTabs(updatedTabs));

        // فقط اگر تب حذف‌شده فعال بود، تب دیگری رو انتخاب کن
        if (id === appConf.activeTab) {
            let nextActiveTab: string;

            if (updatedTabs.length > 0) {
                if (deletedIndex < updatedTabs.length) {
                    // تب بعدی موجود است
                    nextActiveTab = updatedTabs[deletedIndex].id;
                } else {
                    // تب حذف‌شده آخرین تب بود، آخرین تب باقی‌مانده را انتخاب کن
                    nextActiveTab = updatedTabs[updatedTabs.length - 1].id;
                }
            } else {
                // اگر هیچ تب دیگری نیست، داشبرد را انتخاب کن
                nextActiveTab = 'dashboard';
            }

            // سپس tab فعال را تغییر بده
            dispatch(setActiveTab(nextActiveTab));
            router.replace(`?tab=${nextActiveTab}`);
        }
    };

    const handleTabClick = (tabId: string) => {
        dispatch(setActiveTab(tabId));
        router.replace(`?tab=${tabId}`);
    };

    const getFilterData = (key: string, tab?: ITabData) => {
        const active = appConf.tabs.find((t) => t.id === appConf.activeTab)!;
        const targetTab = tab || active;
        let _data = '';
        if (Array.isArray(targetTab?.filters)) {
            const idFilter = targetTab.filters.find((f) => f.key === key);
            _data = idFilter?.value || '';
        } else if (targetTab?.filters && typeof targetTab.filters === 'object') {
            _data = (targetTab.filters as any).value.toString() || '';
        }
        return _data;
    }

    const getParamData = (key: string, tab?: ITabData) => {
        const active = appConf.tabs.find((t) => t.id === appConf.activeTab)!;
        const targetTab = tab || active;
        let _data = '';
        if (Array.isArray(targetTab?.params)) {
            const idFilter = targetTab.params.find((f) => f.key === key);
            _data = idFilter?.value || '';
        } else if (targetTab?.params && typeof targetTab.params === 'object') {
            _data = (targetTab.params as any).value.toString() || '';
        }
        return _data;
    }

    const active: ITabData = appConf.tabs.find((t) => t.id === appConf.activeTab)!;
    const _tabs = [...appConf.tabs].sort((a, b) => a.orther - b.orther);

    const renderContent = () => {

        switch (active.id) {
            case "dashboard":
                return <Dashboard key={active.id} />;

            case "company":
                if (active.key == "add") return <CompanyAdd key={active.id} />
                if (active.key == "edit") return <CompanyEdit key={active.id} id={getParamData('id')} />;
                return <Company key={active.id} />;

            case "fiscalyear":
                if (active.key == "add") return <FiscalYearAdd key={active.id} />
                if (active.key == "edit") return <FiscalYearEdit key={active.id} id={getParamData('id')} />;
                return <FiscalYear key={active.id} />;

            case "companytradingcode":
                if (active.key == "add") return <CompanyTradingCodeAdd key={active.id} />
                if (active.key == "edit") return <CompanyTradingCodeEdit key={active.id} id={getParamData('id')} />;
                if (active.key == "tradingcodediscount") return <TradingCodeDiscount key={active.id} tradingCodeId={getFilterData('tradingCodeId')} tradingCode={getFilterData('tradingCode')} />;
                if (active.key == "tradingcodediscount/add") return <TradingCodeDiscountAdd key={active.id} tradingCodeId={getFilterData('tradingCodeId')} tradingCode={getFilterData('tradingCode')} />;
                if (active.key == "tradingcodediscount/edit") return <TradingCodeDiscountEdit key={active.id} id={getFilterData('id')} tradingCodeId={getFilterData('tradingCodeId')} tradingCode={getFilterData('tradingCode')} />;

                return <CompanyTradingCode key={active.id} />;

            case "stock":
                if (active.key == "view") return <StockView key={active.id} id={getParamData('id')} master={getParamData('master')} />;
                return <Stock key={active.id} />;

            case "share":
                if (active.key == "add") return <ShareAdd key={active.id} />;
                if (active.key == "addt") return <ShareAddT key={active.id} />;
                if (active.key == "edit") return <ShareEdit key={active.id} id={getParamData('id')} />;
                if (active.key == "stock/view") return <StockView key={active.id} id={getParamData('id')} master={getParamData('master')} />;
                if (active.key == "shareinitialbalance") return <Shareinitialbalance key={active.id} id={getParamData('id')} name={getParamData('name')} />;
                if (active.key == "shareinitialbalance/add") return <ShareinitialbalanceAdd key={active.id} shareId={getParamData('shareId')} name={getParamData('name')} />;
                if (active.key == "shareinitialbalance/edit") return <ShareinitialbalanceEdit key={active.id} id={getParamData('id')} shareId={getParamData('shareId')} name={getParamData('name')} />;

                return <Share key={active.id} />;

            case "sharerelationtype":
                if (active.key == "add") return <ShareRelationTypeAdd key={active.id} />;
                if (active.key == "edit") return <ShareRelationTypeEdit key={active.id} id={getParamData('id')} />;
                return <ShareRelationType key={active.id} />;

            case "companybroker":
                if (active.key == "add") return <CompanyBrokerAdd key={active.id} />;
                if (active.key == "all") return <CompanyBrokerAll key={active.id} />;
                if (active.key == "edit") return <CompanyBrokerEdit key={active.id} id={getParamData('id')} />;
                if (active.key == "code") return <CompanyBrokerCode key={active.id} id={getParamData('id')} brokerName={getParamData('brokerName')} master={getParamData('master')} />;
                if (active.key == "companybrokerdiscount") return <Companybrokerdiscount key={active.id} id={getParamData('id')} brokerName={getParamData('brokerName')} />;
                if (active.key == "companybrokerdiscount/add") return <CompanybrokerdiscountAdd key={active.id} id={getParamData('tradingCodeId')} brokerName={getParamData('brokerName')} />;
                if (active.key == "companybrokerdiscount/edit") return <CompanybrokerdiscountEdit key={active.id} id={getParamData('tradingCodeId')} brokerName={getParamData('brokerName')} />;
                return <CompanyBroker key={active.id} />;

            case "companybrokerall":
                return <CompanyBrokerAll key={active.id} />;

            case "accountingArticleElements":
                if (active.key == "add") return <ArticleElementsAdd key={active.id} />;
                if (active.key == "edit") return <ArticleElementsEdit key={active.id} />;
                return <ArticleElements key={active.id} />;

            case "issueDocument":
                return <JournalArticle key={active.id} />;

            case "accountingVoucherTemplates":
                if (active.key == "add") return <VoucherTemplatesAdd key={active.id} />;
                return <VoucherTemplates key={active.id} />;

            case "buysell":
                return <BuySell key={active.id} />;

            case "stackedbuysell":
                return <StackedBuySell key={active.id} />;

            case "shareturnover":
                return <ShareTurnover key={active.id} />;

            case "cardex":
                return <Cardex key={active.id} />;

            case "stackedcardex":
                return <StackedCardex key={active.id} />;

            case "sharebalance":
                return <ShareBalance key={active.id} />;

            case "realizedprofit":
                return <RealizedProfit key={active.id} />;

            case "investmentdepreciationreserve":
                return <InvestmentDepreciationReserve key={active.id} />;

            case "capitalraise":
                return <CapitalRaise key={active.id} />;

            case "cashdividend":
                return <CashDividend key={active.id} />;

            case "cashdividenddeposit":
                return <CashDividendDeposit key={active.id} />;

            case "marketnotice":
                return <MarketNotice key={active.id} />;

            case "comprehensive":
                return <Comprehensive key={active.id} />;

            case "consolidation":
                return <Consolidation key={active.id} />;

            case "transactionimportsession":
                if (active.key == "view") return <TransactionImportSessionDetail key={active.id} id={getParamData('id')} />;
                return <TransactionImportSession key={active.id} />;

            case "sharetransactionbatch":
                return <ShareTransactionBatch key={active.id} />;

            case "sharetransactionbatchnoburs":
                if (active.key == "add") return <ShareTransactionBatchNoBursAdd key={active.id} />;
                if (active.key == "edit") return <ShareTransactionBatchNoBursEdit key={active.id} id={getParamData('id', active)} />;
                return <ShareTransactionBatchNoBurs key={active.id} />;

            case "sharetransactionbatchtadilat":
                return <ShareTransactionBatchTadilat key={active.id} />;

            case "transfercodetocode":
                if (active.key == "add") return <TransferCodeToCodeAdd key={active.id} shareId={getParamData('shareId', active)} />;
                return <TransferCodeToCode key={active.id} />;

            case "sharemeeting":
                return <ShareMeeting key={active.id} />;

            case "brokercontradictions":
                return <BrokerContradictions key={active.id} />;

            case "optioncontract":
                return <OptionContract key={active.id} />;

            case "transactioncommission":
                return <TransactionCommission key={active.id} />;

            case "transactioncommissiondiscount":
                return <TransactionCommissionDiscount key={active.id} />;

            case "transactioncommissiondiscountapply":
                return <TransactionCommissionDiscountapply key={active.id} />;

            case "transactioncommissiondiscountremove":
                return <TransactionCommissionDiscountremove key={active.id} />;

            default:
                return <></>;
        }
    };

    return (
        <div className="w-full mx-auto mt-1">
            {/* نوار تب‌ها */}
            <div className="flex items-center justify-between">
                <div className="flex flex-wrap w-full gap-2 mb-[-1px]">
                    {_tabs.map((tab) => (
                        <div
                            key={tab.id}
                            onClick={() => handleTabClick(tab.id)}
                            className={`pr-4 pl-2 py-2 rounded-t-lg border border-b transition-all border-gray-300 bg-gray-100 ${appConf.activeTab === tab.id
                                ? "border-gray-300 text-gray-700 bg-white border-b border-b-white"
                                : "border hover:text-black hover:bg-gray-200"
                                }`}
                        >
                            {tab.id == 'dashboard' ? <div className="flex h-full ">
                                <i className={`fa-duotone fa-solid fa-gauge text-2xl ${appConf.activeTab === tab.id ? 'text-[#1b647e]' : 'text-gray-600 hover:t'}`} />
                            </div> :
                                <div className="flex"><div className={`${appConf.activeTab === tab.id ? 'text-gray-600 font-bold hover:text-gray-900' : 'text-gray-600'}`}>{t(tab.title)}</div>
                                    <Tooltip label={`حذف ${t(tab.id)}`}>
                                        <ActionIcon
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                removeTab(tab.id);
                                            }}
                                            className="mr-2 flex items-center rounded-xl w-9 h-9 p-0 !bg-transparent !hover:bg-red-500">
                                            <i className={`fa-duotone fa-solid fa-xmark text-sm ${appConf.activeTab === tab.id ? 'text-gray-700' : 'text-gray-700 hover:text-gray-900'}`} />
                                        </ActionIcon>
                                    </Tooltip></div>
                            }

                        </div>
                    ))}
                </div>
            </div>

            {/* محتوای تب فعال */}
            <div className="bg-white rounded-b-md shadow border border-gray-300">
                <div className="space-y-3">
                    {_tabs.map((tab) => (
                        <div
                            key={tab.id}
                            className={appConf.activeTab === tab.id ? 'block' : 'hidden'}
                        >
                            {tab.id === "dashboard" && <Dashboard />}

                            {tab.id === "company" && (
                                <>
                                    {tab.key === "add" && <CompanyAdd />}
                                    {tab.key === "edit" && <CompanyEdit id={getParamData('id', tab)} />}
                                    {tab.key === "company" && <Company />}
                                </>
                            )}

                            {tab.id === "fiscalyear" && (
                                <>
                                    {tab.key === "add" && <FiscalYearAdd />}
                                    {tab.key === "edit" && <FiscalYearEdit id={getParamData('id', tab)} />}
                                    {tab.key === "fiscalyear" && <FiscalYear />}
                                </>
                            )}

                            {tab.id === "companytradingcode" && (
                                <>
                                    {tab.key === "add" && <CompanyTradingCodeAdd />}
                                    {tab.key === "edit" && <CompanyTradingCodeEdit id={getParamData('id', tab)} />}
                                    {tab.key === "tradingcodediscount" && <TradingCodeDiscount tradingCodeId={getFilterData('tradingCodeId', tab)} tradingCode={getFilterData('tradingCode', tab)} />}
                                    {tab.key === "tradingcodediscount/add" && <TradingCodeDiscountAdd tradingCodeId={getFilterData('tradingCodeId', tab)} tradingCode={getFilterData('tradingCode', tab)} />}
                                    {tab.key === "tradingcodediscount/edit" && <TradingCodeDiscountEdit id={getFilterData('id', tab)} tradingCodeId={getFilterData('tradingCodeId', tab)} tradingCode={getFilterData('tradingCode', tab)} />}
                                    {tab.key === "companytradingcode" && <CompanyTradingCode />}
                                </>
                            )}

                            {tab.id === "stock" && (
                                <>
                                    {tab.key === "view" && <StockView id={getParamData('id', tab)} master={getParamData('master', tab)} />}
                                    {tab.key === "stock" && <Stock />}
                                </>
                            )}

                            {tab.id === "share" && (
                                <>
                                    {tab.key === "add" && <ShareAdd />}
                                    {tab.key === "addt" && <ShareAddT />}
                                    {tab.key === "edit" && <ShareEdit id={getParamData('id', tab)} />}
                                    {tab.key === "stock/view" && <StockView id={getParamData('id', tab)} master={getParamData('master', tab)} />}
                                    {tab.key === "shareinitialbalance" && <Shareinitialbalance id={getParamData('id', tab)} name={getParamData('name', tab)} />}
                                    {tab.key === "shareinitialbalance/add" && <ShareinitialbalanceAdd shareId={getParamData('shareId', tab)} name={getParamData('name', tab)} />}
                                    {tab.key === "shareinitialbalance/edit" && <ShareinitialbalanceEdit id={getParamData('id', tab)} shareId={getParamData('shareId', tab)} name={getParamData('name', tab)} />}
                                    {tab.key === "share" && <Share />}
                                </>
                            )}

                            {tab.id === "sharerelationtype" && (
                                <>
                                    {tab.key === "add" && <ShareRelationTypeAdd />}
                                    {tab.key === "edit" && <ShareRelationTypeEdit id={getParamData('id', tab)} />}
                                    {tab.key === "sharerelationtype" && <ShareRelationType />}
                                </>
                            )}

                            {tab.id === "companybroker" && (
                                <>
                                    {tab.key === "add" && <CompanyBrokerAdd />}
                                    {tab.key === "all" && <CompanyBrokerAll />}
                                    {tab.key === "edit" && <CompanyBrokerEdit id={getParamData('id', tab)} />}
                                    {tab.key === "code" && <CompanyBrokerCode id={getParamData('id', tab)} brokerName={getParamData('brokerName', tab)} master={getParamData('master', tab)} />}
                                    {tab.key === "companybrokerdiscount" && <Companybrokerdiscount id={getParamData('id', tab)} brokerName={getParamData('brokerName', tab)} />}
                                    {tab.key === "companybrokerdiscount/add" && <CompanybrokerdiscountAdd id={getParamData('id', tab)} brokerName={getParamData('brokerName', tab)} />}
                                    {tab.key === "companybrokerdiscount/edit" && <CompanybrokerdiscountEdit id={getParamData('id', tab)} brokerName={getParamData('brokerName', tab)} />}
                                    {tab.key === "companybroker" && <CompanyBroker />}
                                </>
                            )}

                            {tab.id === "accountingArticleElements" && (
                                <>
                                    {tab.key === "add" && <ArticleElementsAdd />}
                                    {tab.key === "edit" && <ArticleElementsEdit />}
                                    {tab.key === "accountingArticleElements" && <ArticleElements />}
                                </>
                            )}

                            {tab.id === "issueDocument" && <JournalArticle />}

                            {tab.id === "accountingVoucherTemplates" && (
                                <>
                                    {tab.key === "add" && <VoucherTemplatesAdd />}
                                    {tab.key === "accountingVoucherTemplates" && <VoucherTemplates />}
                                </>
                            )}

                            {tab.id === "buysell" && <BuySell />}
                            {tab.id === "stackedbuysell" && <StackedBuySell />}
                            {tab.id === "shareturnover" && <ShareTurnover />}
                            {tab.id === "cardex" && <Cardex />}
                            {tab.id === "stackedcardex" && <StackedCardex />}
                            {tab.id === "sharebalance" && <ShareBalance />}
                            {tab.id === "realizedprofit" && <RealizedProfit />}
                            {tab.id === "investmentdepreciationreserve" && <InvestmentDepreciationReserve />}
                            {tab.id === "capitalraise" && <CapitalRaise />}
                            {tab.id === "cashdividend" && <CashDividend />}
                            {tab.id === "cashdividenddeposit" && <CashDividendDeposit />}
                            {tab.id === "marketnotice" && <MarketNotice />}
                            {tab.id === "comprehensive" && <Comprehensive />}
                            {tab.id === "consolidation" && <Consolidation />}
                            {tab.id === "transactionimportsession" && (
                                <>
                                    {tab.key === "view" && <TransactionImportSessionDetail id={getParamData('id', tab)} />}
                                    {tab.key === "transaction" && <TransactionImportSessionTransaction id={getParamData('id', tab)} />}
                                    {tab.key === "transactionimportsession" && <TransactionImportSession />}
                                </>
                            )}

                            {tab.id === "sharetransactionbatch" && <ShareTransactionBatch />}

                            {tab.id === "sharetransactionbatchnoburs" && (
                                <>
                                    {tab.key === "add" && <ShareTransactionBatchNoBursAdd />}
                                    {tab.key === "edit" && <ShareTransactionBatchNoBursEdit id={getParamData('id', tab)} />}
                                    {tab.key === "transfercodetocode" && <ShareTransactionBatchNoBurs />}
                                </>
                            )}

                            {tab.id === "sharetransactionbatchtadilat" && <ShareTransactionBatchTadilat />}

                            {tab.id === "transfercodetocode" && (
                                <>
                                    {tab.key === "add" && <TransferCodeToCodeAdd shareId={getParamData('shareId', tab)} />}
                                    {tab.key === "transfercodetocode" && <TransferCodeToCode />}
                                </>
                            )}

                            {tab.id === "sharemeeting" && <ShareMeeting />}

                            {tab.id === "brokercontradictions" && <BrokerContradictions />}

                            {tab.id === "optioncontract" && <OptionContract />}

                            {tab.id === "transactioncommission" && <TransactionCommission />}

                            {tab.id === "transactioncommissiondiscount" && <TransactionCommissionDiscount />}

                            {tab.id === "jobs" && <Jobs />}

                            {tab.id === "running" && <Running />}

                            {tab.id === "finished" && <Finished />}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}