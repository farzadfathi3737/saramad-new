'use client'

import ShareHolding from "./Shareholding/page";

export default function Home() {

  return (
    <>
      <ShareHolding />
    </>
  );
}
