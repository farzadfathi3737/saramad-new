'use client'

// import TabPage from "./components/tabPage";
import ShareHolding from "./Shareholding/page";

export default function Home() {

  return (
    <>
      <ShareHolding />
    </>
  );
}
