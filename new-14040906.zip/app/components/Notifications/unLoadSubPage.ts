'use client'

import { ITabData } from '@/interface/dataModel';
import { IRootState } from '@/store';
import { setTabs } from '@/store/appConfigSlice';
import { useDispatch, useSelector } from 'react-redux';

export function useUnloadSubPage() {
    const appConf = useSelector((state: IRootState) => state.appConfig);
    const dispatch = useDispatch();

    const unload = (cmpName: string) => {
        const _newTabs: ITabData[] = appConf.tabs.filter((x) => x.id !== cmpName)!;
        const _newTab: ITabData = appConf.tabs.find((x) => x.id == cmpName)!;

        if (_newTab) {
            const newTab = { ..._newTab, key: cmpName, filters: [] };
            const updatedTabs = [..._newTabs, newTab];
            dispatch(setTabs(updatedTabs));
        }
    };

    return unload;
}